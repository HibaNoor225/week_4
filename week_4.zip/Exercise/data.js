const tasks=[{id:1,title:"Work",description:"Internship work",completed:true}]
module.exports=tasks;